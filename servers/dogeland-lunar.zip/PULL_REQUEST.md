Tiêu đề PR:  Add Dogeland Network

Nội dung PR:
Adding Dogeland Network (play.dogeland.vn), a Vietnamese Survival SMP.

- Server ID: dogeland
- Primary address: play.dogeland.vn
- Version: 1.21.11
- Region: Asia
- Website: https://dogeland.vn
- Discord: https://discord.gg/fEkF3cSCBq

Files: servers/dogeland/metadata.json, logo.png (1024x1024), background.png (1920x1080), wordmark.png (1920x1080)
